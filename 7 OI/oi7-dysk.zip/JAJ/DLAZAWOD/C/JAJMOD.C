#include "jajmod.h"

long int wysokosc; /* tu b�dzie zapisana wysoko�� drapacza, jaki mamy
		      do dyspozycji podczas eksperymentu */

int jajka;         /* tu b�dzie zapisana liczba jajek dost�pnych podczas
		      eksperymentu */

long int pietro;   /* tu funkcja daj_pytanie powinna umieszcza� numer
                      pi�tra, z kt�rego ma by� zrzucone jajko */

int odpowiedz;     /* tu b�dzie odpowied� na pytanie, czy zrzucone
                      jajko rozbi�o si� */

int wiem;          /* tu nale�y wpisa� TAK, je�li wiem jaka jest
                      wytrzyma�o�� jajka; w przeciwnym razie warto�ci�
                      tej zmiennej powinno by� NIE */

long int x;        /* jesli wiem == TAK, to tu nale�y wpisa�
                      wytrzyma�o�� jajka */
